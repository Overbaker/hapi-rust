| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-off | 1.4.4 | 0.056 ± 0.003 | 0.117 | 3.514 ± 0.030 | 3.932 | 46.310 ± 0.053 | 6–9 | 52 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| claude | 1.3.11 | 0.313 ± 0.030 | 0.400 | 139.630 ± 5.468 | 165.132 | 147.624 ± 0.386 | 12–15 | 5 |

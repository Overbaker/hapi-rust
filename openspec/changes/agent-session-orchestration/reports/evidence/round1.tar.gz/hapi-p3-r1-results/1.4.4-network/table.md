| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| network | 1.4.4 | 0.050 ± 0.001 | 0.117 | 3.485 ± 0.048 | 4.134 | 42.921 ± 0.072 | 2–3 | 30 |

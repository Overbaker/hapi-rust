| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| bare | 1.4.4 | 0.001 ± 0.001 | 0.017 | 0.340 ± 0.008 | 0.450 | 3.790 ± 0.013 | 2–2 | 0 |

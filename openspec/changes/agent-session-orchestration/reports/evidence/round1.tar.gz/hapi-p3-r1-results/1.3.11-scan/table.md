| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan | 1.3.11 | 0.356 ± 0.017 | 0.433 | 184.952 ± 7.615 | 212.094 | 97.985 ± 0.080 | 12–12 | 5 |

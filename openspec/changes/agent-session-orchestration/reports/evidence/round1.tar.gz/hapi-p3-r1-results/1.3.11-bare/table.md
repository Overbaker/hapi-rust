| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| bare | 1.3.11 | 0.012 ± 0.003 | 0.033 | 0.705 ± 0.023 | 0.900 | 10.419 ± 0.084 | 2–2 | 50 |

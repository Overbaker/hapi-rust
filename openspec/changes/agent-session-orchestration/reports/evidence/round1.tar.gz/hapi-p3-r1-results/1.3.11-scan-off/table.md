| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan-off | 1.3.11 | 0.021 ± 0.001 | 0.083 | 3.247 ± 0.372 | 25.717 | 97.064 ± 0.325 | 5–14 | 125 |

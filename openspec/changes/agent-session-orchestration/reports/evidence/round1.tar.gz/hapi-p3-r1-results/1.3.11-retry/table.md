| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry | 1.3.11 | 0.743 ± 0.109 | 1.267 | 330.695 ± 55.063 | 637.700 | 98.640 ± 0.029 | 12–12 | 5 |

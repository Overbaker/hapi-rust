| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| network | 1.3.11 | 0.190 ± 0.008 | 0.283 | 43.875 ± 6.970 | 113.016 | 122.275 ± 0.244 | 2–9 | 275 |

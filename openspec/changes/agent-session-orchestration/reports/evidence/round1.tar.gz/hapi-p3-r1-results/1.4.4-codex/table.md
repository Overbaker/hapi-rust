| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| codex | 1.4.4 | 0.059 ± 0.001 | 0.133 | 3.791 ± 0.058 | 4.317 | 46.916 ± 0.251 | 6–9 | 44 |

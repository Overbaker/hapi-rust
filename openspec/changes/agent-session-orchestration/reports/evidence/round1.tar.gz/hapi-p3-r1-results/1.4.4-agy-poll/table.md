| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-poll | 1.4.4 | 0.122 ± 0.001 | 0.167 | 12.020 ± 0.142 | 15.900 | 45.910 ± 0.302 | 13–18 | 443 |

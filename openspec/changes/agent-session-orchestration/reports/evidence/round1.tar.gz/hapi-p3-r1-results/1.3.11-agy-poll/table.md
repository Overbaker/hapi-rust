| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-poll | 1.3.11 | 1.021 ± 0.069 | 2.083 | 470.507 ± 36.841 | 952.677 | 135.379 ± 0.355 | 13–17 | 46 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| historic | 1.4.4 | 0.062 ± 0.003 | 0.133 | 3.765 ± 0.030 | 4.200 | 57.240 ± 0.981 | 5–9 | 55 |

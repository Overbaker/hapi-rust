| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan | 1.4.4 | 0.037 ± 0.002 | 0.067 | 4.821 ± 0.015 | 5.150 | 20.716 ± 0.111 | 5–6 | 53 |

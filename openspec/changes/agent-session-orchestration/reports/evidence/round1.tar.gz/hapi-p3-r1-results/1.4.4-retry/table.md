| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry | 1.4.4 | 0.128 ± 0.004 | 0.167 | 16.668 ± 1.337 | 25.886 | 21.440 ± 0.206 | 6–14 | 191 |

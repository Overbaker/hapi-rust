| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy | 1.4.4 | 0.126 ± 0.003 | 0.183 | 12.072 ± 0.162 | 14.867 | 45.528 ± 0.205 | 13–18 | 433 |

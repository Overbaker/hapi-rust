| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-off | 1.3.11 | 0.299 ± 0.016 | 0.367 | 139.341 ± 2.919 | 153.733 | 134.788 ± 0.257 | 13–17 | 46 |

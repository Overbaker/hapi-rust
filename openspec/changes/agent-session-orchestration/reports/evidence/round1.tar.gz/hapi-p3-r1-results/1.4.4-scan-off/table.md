| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan-off | 1.4.4 | 0.010 ± 0.001 | 0.033 | 0.507 ± 0.026 | 0.717 | 20.134 ± 0.076 | 5–7 | 0 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry-off | 1.3.11 | 0.501 ± 0.005 | 0.567 | 263.662 ± 4.293 | 280.497 | 98.234 ± 0.124 | 12–13 | 20 |

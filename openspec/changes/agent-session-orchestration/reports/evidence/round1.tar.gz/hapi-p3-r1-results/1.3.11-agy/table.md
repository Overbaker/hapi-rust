| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy | 1.3.11 | 0.909 ± 0.166 | 2.033 | 426.613 ± 70.681 | 913.524 | 137.478 ± 0.383 | 13–17 | 50 |

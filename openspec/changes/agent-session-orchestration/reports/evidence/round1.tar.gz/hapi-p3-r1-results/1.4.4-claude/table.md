| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| claude | 1.4.4 | 0.057 ± 0.001 | 0.117 | 3.664 ± 0.023 | 3.949 | 49.256 ± 0.295 | 5–9 | 61 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry-off | 1.4.4 | 0.053 ± 0.001 | 0.083 | 5.360 ± 0.124 | 7.370 | 21.076 ± 0.111 | 5–13 | 83 |

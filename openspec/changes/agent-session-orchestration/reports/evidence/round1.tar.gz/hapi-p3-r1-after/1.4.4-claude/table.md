| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| claude | 1.4.4 | 0.062 ± 0.003 | 0.133 | 3.625 ± 0.026 | 3.982 | 50.177 ± 0.254 | 5–9 | 56 |

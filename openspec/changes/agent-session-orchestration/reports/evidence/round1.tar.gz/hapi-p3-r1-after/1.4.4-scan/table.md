| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan | 1.4.4 | 0.012 ± 0.001 | 0.033 | 0.846 ± 0.035 | 1.117 | 22.431 ± 0.030 | 5–5 | 0 |

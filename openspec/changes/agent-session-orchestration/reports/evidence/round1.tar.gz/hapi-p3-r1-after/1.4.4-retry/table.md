| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry | 1.4.4 | 0.055 ± 0.002 | 0.083 | 5.879 ± 0.163 | 7.533 | 21.682 ± 0.071 | 6–15 | 193 |

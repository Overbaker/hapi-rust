| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| retry-off | 1.4.4 | 0.050 ± 0.001 | 0.083 | 5.395 ± 0.122 | 6.900 | 21.753 ± 0.139 | 5–13 | 127 |

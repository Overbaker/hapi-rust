| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy | 1.4.4 | 0.058 ± 0.001 | 0.100 | 5.286 ± 0.066 | 6.950 | 44.803 ± 0.175 | 13–17 | 432 |

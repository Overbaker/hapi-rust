| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| codex | 1.4.4 | 0.058 ± 0.002 | 0.100 | 3.805 ± 0.032 | 4.083 | 46.944 ± 0.221 | 5–9 | 40 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| scan-off | 1.4.4 | 0.009 ± 0.001 | 0.033 | 0.455 ± 0.010 | 0.717 | 20.985 ± 0.018 | 5–5 | 0 |

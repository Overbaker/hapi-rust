| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-off | 1.4.4 | 0.054 ± 0.003 | 0.100 | 5.128 ± 0.221 | 7.583 | 48.098 ± 0.149 | 13–17 | 428 |

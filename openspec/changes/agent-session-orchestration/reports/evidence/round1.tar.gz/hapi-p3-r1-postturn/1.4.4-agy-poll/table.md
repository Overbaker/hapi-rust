| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy-poll | 1.4.4 | 0.121 ± 0.002 | 0.183 | 12.088 ± 0.075 | 14.899 | 48.579 ± 0.102 | 13–18 | 434 |

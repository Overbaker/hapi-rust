| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy | 1.4.4 | 0.055 ± 0.003 | 0.133 | 5.147 ± 0.146 | 7.316 | 45.679 ± 0.350 | 7–17 | 416 |

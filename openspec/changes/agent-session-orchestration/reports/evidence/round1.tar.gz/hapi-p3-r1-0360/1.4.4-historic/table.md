| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| historic | 1.4.4 | 0.073 ± 0.002 | 0.150 | 4.959 ± 0.021 | 5.450 | 57.058 ± 0.313 | 5–11 | 68 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| auth-rejected | 1.3.11 | 0.346 ± 0.013 | 0.467 | 98.355 ± 8.430 | 133.415 | 147.289 ± 0.295 | 12–14 | 0 |

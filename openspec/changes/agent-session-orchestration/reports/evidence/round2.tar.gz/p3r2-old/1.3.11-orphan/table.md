| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| orphan | 1.3.11 | 0.586 ± 0.011 | 0.700 | 180.729 ± 6.812 | 207.469 | 147.918 ± 0.126 | 13–14 | 25 |

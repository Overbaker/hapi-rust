| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| bare | 1.3.11 | 0.015 ± 0.001 | 0.033 | 0.683 ± 0.018 | 0.900 | 7.763 ± 0.051 | 2–2 | 50 |

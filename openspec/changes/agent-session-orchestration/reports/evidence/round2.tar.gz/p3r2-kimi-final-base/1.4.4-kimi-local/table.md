| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| kimi-local | 1.4.4 | 0.156 ± 0.006 | 0.200 | 25.751 ± 0.629 | 28.629 | 55.664 ± 0.187 | 13–18 | 422 |

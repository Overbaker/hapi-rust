| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| kimi-local | 1.4.4 | 0.140 ± 0.002 | 0.200 | 23.259 ± 0.135 | 25.134 | 52.669 ± 0.257 | 13–17 | 429 |

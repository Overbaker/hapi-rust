| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| bare | 1.4.4 | 0.001 ± 0.001 | 0.017 | 0.339 ± 0.006 | 0.400 | 2.390 ± 0.004 | 2–2 | 0 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| agy | 1.4.4 | 0.049 ± 0.001 | 0.083 | 3.660 ± 0.032 | 3.965 | 45.110 ± 0.089 | 6–9 | 49 |

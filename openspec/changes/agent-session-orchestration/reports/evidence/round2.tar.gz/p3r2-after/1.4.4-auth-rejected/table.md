| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| auth-rejected | 1.4.4 | 0.020 ± 0.001 | 0.067 | 0.749 ± 0.049 | 0.967 | 48.770 ± 0.209 | 5–6 | 0 |

| Workload | Bun | CPU % mean ± SD | Max CPU % | Slices/s mean ± SD | Max slices/s | PSS MiB mean ± SD | Threads min–max | Lost TIDs |
|---|---|---:|---:|---:|---:|---:|---:|---:|
| orphan | 1.4.4 | 0.057 ± 0.002 | 0.100 | 2.169 ± 0.058 | 2.633 | 50.615 ± 0.403 | 7–10 | 80 |
